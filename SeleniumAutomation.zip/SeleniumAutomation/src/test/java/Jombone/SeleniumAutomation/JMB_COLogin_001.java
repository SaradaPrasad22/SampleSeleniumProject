package Jombone.SeleniumAutomation;

import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import org.testng.AssertJUnit;
import java.io.IOException;

import org.testng.Assert;
import org.testng.annotations.Test;

import pageObject.landingPage;
import pageObject.loginPage;
import resources.baseutil;

public class JMB_COLogin_001 extends baseutil{

	@BeforeTest
	public void initialize() throws IOException {
		
		driver= initializeDriver();
		
	}
	@Test
	public void primaryContentOfLoginFormValidation() throws IOException {
		
		
		//Navigate to jombone page
		driver.get(prp.getProperty("url"));
		//AC01: Jombone webpage should open
		AssertJUnit.assertEquals(driver.getTitle(), "Jombone");
		
		landingPage l=new landingPage(driver);
		//On Landing Welcome page ,Click on Login button on right side
		l.getLogin().click();
		
		//AC02: Login page should open
		AssertJUnit.assertEquals(driver.getTitle(), "Login");
		
		loginPage l1= new loginPage(driver);
		
		//AC03: Primary Content must be there on login form.
		//a.Email textbox
		//b.Password textbox
		//c. Login button
		
		AssertJUnit.assertEquals(true, l1.getEmail().isDisplayed());
		AssertJUnit.assertEquals(true, l1.getPassword().isDisplayed());
		AssertJUnit.assertEquals(true, l1.getSubmit().isDisplayed());
		
		
		
		
	}
	
	@AfterTest
	public void teardown() {
		
		driver.close();
		
		
	}

}
