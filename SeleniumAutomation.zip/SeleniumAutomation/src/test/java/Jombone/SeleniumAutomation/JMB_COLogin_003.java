package Jombone.SeleniumAutomation;

import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import org.testng.AssertJUnit;
import java.io.IOException;

import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.annotations.Test;

import pageObject.landingPage;
import pageObject.loginPage;
import resources.baseutil;

public class JMB_COLogin_003 extends baseutil{
	
	
	@BeforeTest
	public void initialize() throws IOException {
		
		driver= initializeDriver();
		
	}
	
	@Test
	public void primaryContentOfLoginFormValidation() throws IOException {
		
		
		//Navigate to jombone page
		driver.get(prp.getProperty("url"));
		//AC01: Jombone webpage should open
		AssertJUnit.assertEquals(driver.getTitle(), "Jombone");
		
		landingPage l=new landingPage(driver);
		
		//On Landing Welcome page ,Click on Login button on right side
		l.getLogin().click();
		
		//AC02: Login page should open
		AssertJUnit.assertEquals(driver.getTitle(), "Login");
		
		
		// Enter Invalid email and Invalid  password > Click Login
		
		loginPage l1= new loginPage(driver);
		l1.getEmail().sendKeys("Test1@gmail.com");
		l1.getPassword().sendKeys("Pdw123");
		l1.getSubmit().click();
		
		
		//AC03: Company user  should not  login successfully
		//AC04: And  a validation error message "INVALID CREDENTIALS"  should displayed.
		
		String expected_error = driver.findElement(By.xpath("//div[@class='toast-message']")).getText();
		
		AssertJUnit.assertEquals(expected_error, "Invalid credentials.");

		
		
		
	}
	
	@AfterTest
	public void teardown() {
		
		driver.close();
		
		
	}

}
