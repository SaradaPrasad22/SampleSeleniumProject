package pageObject;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class loginPage {

	public WebDriver driver;
	//By email = By.xpath("[id='email']");
	By email = By.id("email");
	By pwd = By.id("password-field");
	By loginbutton = By.id("sbBt");

	public loginPage(WebDriver driver2) {
		this.driver = driver2;
	}

	public WebElement getEmail() {

		return driver.findElement(email);
	}

	public WebElement getPassword() {

		return driver.findElement(pwd);
	}

	public WebElement getSubmit() {

		return driver.findElement(loginbutton);
	}

}
