package pageObject;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class landingPage {
	
	public WebDriver driver;
	By login = By.xpath("//a[@href='/login']");
	
	
	
	
	
	public landingPage(WebDriver driver2) {
		this.driver=driver2;
	}




	public WebElement getLogin() {
		
		return driver.findElement(login);
	}
	


}
